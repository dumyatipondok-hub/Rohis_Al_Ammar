// =========================================================================
// DATABASE LOKAL & LOGIKA APLIKASI ROHIS AL AMMAR - SMAN 1 PRONOJIWO
// =========================================================================

const STORAGE_KEYS = {
  PENGURUS: 'rohis_alammar_pengurus_v1',
  KEGIATAN: 'rohis_alammar_kegiatan_v1',
  ANGGOTA: 'rohis_alammar_anggota_v1',
  ABSENSI: 'rohis_alammar_absensi_v1',
  AKUN: 'rohis_alammar_akun_v1',
  SESSION: 'rohis_alammar_session_v1'
};

// Data Awal Default
const DEFAULT_AKUN = [
  { id: '1', nama: 'Dumyati, S.Pd.I., Gr.', username: 'Dumyati', password: '111333', role: 'Pembina / Admin' },
  { id: '2', nama: 'Ikhsan Wijayanto, S.Pd.', username: 'ikhsan.wijayanto', password: '1111333', role: 'Pembina / Admin' }
];

const DEFAULT_PENGURUS = [
  { id: '1', jabatan: 'Penanggung Jawab', nama: 'Haris Sutanto, S.Si., M.M.' },
  { id: '2', jabatan: 'Pembina 1', nama: 'Dumyati, S.Pd.I., Gr.' },
  { id: '3', jabatan: 'Pembina 2', nama: 'Ikhsan Wijayanto, S.Pd.' },
  { id: '4', jabatan: 'Ketua', nama: 'Nurul Andita Sari' },
  { id: '5', jabatan: 'Wakil Ketua', nama: 'Muhammad Rifqi Azzam Zakwan' },
  { id: '6', jabatan: 'Sekretaris', nama: 'Devikha Azzahra' }
];

const DEFAULT_ANGGOTA = [
  { id: '101', nama: 'Nurul Andita Sari', kelas: 'XI IPA 1', jk: 'P', divisi: 'Pengurus Inti' },
  { id: '102', nama: 'Muhammad Rifqi Azzam Zakwan', kelas: 'XI IPA 2', jk: 'L', divisi: 'Pengurus Inti' },
  { id: '103', nama: 'Devikha Azzahra', kelas: 'XI IPS 1', jk: 'P', divisi: 'Pengurus Inti' }
];

let appData = {
  pengurus: [],
  kegiatan: [],
  anggota: [],
  absensi: [],
  akun: []
};

function initApp() {
  appData.akun = JSON.parse(localStorage.getItem(STORAGE_KEYS.AKUN)) || DEFAULT_AKUN;
  appData.pengurus = JSON.parse(localStorage.getItem(STORAGE_KEYS.PENGURUS)) || DEFAULT_PENGURUS;
  appData.anggota = JSON.parse(localStorage.getItem(STORAGE_KEYS.ANGGOTA)) || DEFAULT_ANGGOTA;
  appData.kegiatan = JSON.parse(localStorage.getItem(STORAGE_KEYS.KEGIATAN)) || [];
  appData.absensi = JSON.parse(localStorage.getItem(STORAGE_KEYS.ABSENSI)) || [];
  saveAllToStorage();

  const savedSession = JSON.parse(sessionStorage.getItem(STORAGE_KEYS.SESSION));
  if (savedSession) {
    masukKeDashboard(savedSession);
  }
}

function saveAllToStorage() {
  localStorage.setItem(STORAGE_KEYS.AKUN, JSON.stringify(appData.akun));
  localStorage.setItem(STORAGE_KEYS.PENGURUS, JSON.stringify(appData.pengurus));
  localStorage.setItem(STORAGE_KEYS.ANGGOTA, JSON.stringify(appData.anggota));
  localStorage.setItem(STORAGE_KEYS.KEGIATAN, JSON.stringify(appData.kegiatan));
  localStorage.setItem(STORAGE_KEYS.ABSENSI, JSON.stringify(appData.absensi));
}

// LOGIN & LOGOUT
function handleLogin(e) {
  e.preventDefault();
  const u = document.getElementById('loginUser').value.trim();
  const p = document.getElementById('loginPass').value.trim();
  const errBox = document.getElementById('loginError');

  const found = appData.akun.find(a => a.username === u && a.password === p);
  if (found) {
    errBox.classList.add('hidden');
    sessionStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(found));
    masukKeDashboard(found);
  } else {
    errBox.innerText = 'Username atau Password salah!';
    errBox.classList.remove('hidden');
  }
}

function masukKeDashboard(user) {
  document.getElementById('loggedAdminName').innerText = user.nama;
  document.getElementById('loggedAdminRole').innerText = user.role || 'Admin Rohis';
  document.getElementById('loginPage').classList.add('hidden');
  document.getElementById('mainApp').classList.remove('hidden');
  renderAll();
}

function logout() {
  sessionStorage.removeItem(STORAGE_KEYS.SESSION);
  document.getElementById('loginForm').reset();
  document.getElementById('mainApp').classList.add('hidden');
  document.getElementById('loginPage').classList.remove('hidden');
}

function renderAll() {
  renderPengurus();
  renderKegiatan();
  renderAnggota();
  renderInputAbsensi();
  renderRiwayatAbsensi();
  renderRekap();
  renderAkun();
}

// NAVIGASI TAB
function switchTab(tab) {
  document.querySelectorAll('.tab-section').forEach(s => s.classList.add('hidden'));
  document.getElementById('sec-' + tab).classList.remove('hidden');
  document.querySelectorAll('.nav-btn').forEach(b => {
    b.classList.remove('bg-amber-500', 'text-emerald-950', 'font-bold');
    b.classList.add('text-emerald-100');
  });
  const active = document.getElementById('tab-' + tab);
  active.classList.add('bg-amber-500', 'text-emerald-950', 'font-bold');
  active.classList.remove('text-emerald-100');
}

function switchSubAbsensi(sub) {
  ['input', 'riwayat', 'rekap'].forEach(s => {
    document.getElementById('subAbsen-' + s).classList.add('hidden');
  });
  document.getElementById('subAbsen-' + sub).classList.remove('hidden');
  if (sub === 'rekap') renderRekap();
}

// 1. STRUKTUR KEPENGURUSAN
function renderPengurus() {
  const grid = document.getElementById('gridPengurus');
  grid.innerHTML = appData.pengurus.map(p => `
    <div class="bg-white p-5 rounded-2xl shadow-sm border-l-4 border-emerald-600 flex justify-between items-start">
      <div>
        <span class="text-[11px] font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">${p.jabatan}</span>
        <h3 class="text-base font-extrabold text-emerald-950 mt-2">${p.nama}</h3>
      </div>
      <div class="flex gap-1.5">
        <button onclick="editPengurus('${p.id}')" class="p-2 text-amber-600 hover:bg-amber-50 rounded-lg" title="Edit"><i class="fa-solid fa-pen"></i></button>
        <button onclick="hapusPengurus('${p.id}')" class="p-2 text-red-600 hover:bg-red-50 rounded-lg" title="Hapus"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>
  `).join('');
}

function simpanPengurus(e) {
  e.preventDefault();
  const id = document.getElementById('pengurusId').value;
  const jabatan = document.getElementById('pengurusJabatan').value.trim();
  const nama = document.getElementById('pengurusNama').value.trim();

  if (id) {
    const idx = appData.pengurus.findIndex(x => x.id === id);
    if (idx > -1) appData.pengurus[idx] = { id, jabatan, nama };
  } else {
    appData.pengurus.push({ id: String(Date.now()), jabatan, nama });
  }
  saveAllToStorage();
  resetFormPengurus();
  renderPengurus();
}

function editPengurus(id) {
  const p = appData.pengurus.find(x => x.id === id);
  if (!p) return;
  document.getElementById('pengurusId').value = p.id;
  document.getElementById('pengurusJabatan').value = p.jabatan;
  document.getElementById('pengurusNama').value = p.nama;
}

function hapusPengurus(id) {
  if (!confirm('Hapus pengurus ini?')) return;
  appData.pengurus = appData.pengurus.filter(x => x.id !== id);
  saveAllToStorage();
  renderPengurus();
}

function resetFormPengurus() {
  document.getElementById('pengurusId').value = '';
  document.getElementById('pengurusJabatan').value = '';
  document.getElementById('pengurusNama').value = '';
}

// 2. FOTO KEGIATAN
function simpanKegiatan(e) {
  e.preventDefault();
  const file = document.getElementById('kegFoto').files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(event) {
    const img = new Image();
    img.onload = function() {
      const canvas = document.createElement('canvas');
      const maxW = 800;
      const scale = img.width > maxW ? maxW / img.width : 1;
      canvas.width = img.width * scale;
      canvas.height = img.height * scale;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const base64 = canvas.toDataURL('image/jpeg', 0.75);

      appData.kegiatan.push({
        id: String(Date.now()),
        judul: document.getElementById('kegJudul').value.trim(),
        tanggal: document.getElementById('kegTanggal').value,
        deskripsi: document.getElementById('kegDeskripsi').value.trim(),
        fotoBase64: base64
      });
      saveAllToStorage();
      e.target.reset();
      renderKegiatan();
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(file);
}

function renderKegiatan() {
  const grid = document.getElementById('gridKegiatan');
  if (appData.kegiatan.length === 0) {
    grid.innerHTML = `<p class="text-sm text-slate-500 col-span-3 text-center py-8">Belum ada foto kegiatan yang diunggah.</p>`;
    return;
  }
  grid.innerHTML = appData.kegiatan.slice().reverse().map(k => `
    <div class="bg-white rounded-2xl shadow-sm overflow-hidden border border-emerald-100 flex flex-col">
      <img src="${k.fotoBase64}" class="w-full h-48 object-cover bg-emerald-100" alt="${k.judul}">
      <div class="p-4 flex-1 flex flex-col justify-between">
        <div>
          <span class="text-xs font-bold text-emerald-700"><i class="fa-regular fa-calendar mr-1"></i>${k.tanggal}</span>
          <h3 class="font-extrabold text-slate-900 mt-1">${k.judul}</h3>
          <p class="text-xs text-slate-600 mt-1.5 leading-relaxed">${k.deskripsi}</p>
        </div>
        <div class="mt-4 pt-3 border-t flex justify-end">
          <button onclick="hapusKegiatan('${k.id}')" class="text-xs font-bold text-red-600 hover:underline"><i class="fa-solid fa-trash mr-1"></i>Hapus</button>
        </div>
      </div>
    </div>
  `).join('');
}

function hapusKegiatan(id) {
  if (!confirm('Hapus dokumentasi kegiatan ini?')) return;
  appData.kegiatan = appData.kegiatan.filter(x => x.id !== id);
  saveAllToStorage();
  renderKegiatan();
}

// 3. ABSENSI & REKAP PDF
function renderInputAbsensi() {
  const tglInput = document.getElementById('absTanggal');
  if (!tglInput.value) tglInput.valueAsDate = new Date();
  const tbody = document.getElementById('tbodyInputAbsensi');
  tbody.innerHTML = appData.anggota.map((a, idx) => `
    <tr>
      <td class="p-3">${idx + 1}</td>
      <td class="p-3 font-bold">${a.nama}</td>
      <td class="p-3">${a.kelas}</td>
      <td class="p-3">
        <select id="st-${a.id}" class="border rounded-lg px-2.5 py-1 text-xs font-bold bg-emerald-50">
          <option value="Hadir">Hadir</option>
          <option value="Izin">Izin</option>
          <option value="Sakit">Sakit</option>
          <option value="Alpha">Alpha</option>
        </select>
      </td>
      <td class="p-3">
        <input type="text" id="ket-${a.id}" placeholder="Catatan opsional..." class="border rounded-lg px-2.5 py-1 text-xs w-full">
      </td>
    </tr>
  `).join('');
}

function simpanAbsensiMassal() {
  const tgl = document.getElementById('absTanggal').value;
  const keg = document.getElementById('absKegiatan').value.trim();
  if (!tgl || !keg) return alert('Isi tanggal dan nama kegiatan terlebih dahulu!');

  const now = Date.now();
  appData.anggota.forEach((a, i) => {
    appData.absensi.push({
      id: String(now + i),
      tanggal: tgl,
      kegiatan: keg,
      anggotaId: a.id,
      namaAnggota: a.nama,
      kelas: a.kelas,
      status: document.getElementById('st-' + a.id).value,
      keterangan: document.getElementById('ket-' + a.id).value.trim()
    });
  });

  saveAllToStorage();
  document.getElementById('absKegiatan').value = '';
  renderAll();
  alert('Data absensi berhasil disimpan!');
}

function renderRiwayatAbsensi() {
  const tbody = document.getElementById('tbodyRiwayatAbsensi');
  tbody.innerHTML = appData.absensi.slice().reverse().map(r => `
    <tr>
      <td class="p-3">${r.tanggal}</td>
      <td class="p-3 font-semibold">${r.kegiatan}</td>
      <td class="p-3">${r.namaAnggota}</td>
      <td class="p-3"><span class="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">${r.status}</span></td>
      <td class="p-3 text-xs text-slate-500">${r.keterangan || '-'}</td>
      <td class="p-3 text-center space-x-2">
        <button onclick="bukaModalEditAbsen('${r.id}')" class="text-amber-600 hover:underline text-xs font-bold">Edit</button>
        <button onclick="hapusAbsensi('${r.id}')" class="text-red-600 hover:underline text-xs font-bold">Hapus</button>
      </td>
    </tr>
  `).join('');
}

function bukaModalEditAbsen(id) {
  const r = appData.absensi.find(x => x.id === id);
  if (!r) return;
  document.getElementById('editAbsId').value = r.id;
  document.getElementById('editAbsNama').value = r.namaAnggota;
  document.getElementById('editAbsStatus').value = r.status;
  document.getElementById('editAbsKet').value = r.keterangan;
  document.getElementById('modalEditAbsen').classList.remove('hidden');
  document.getElementById('modalEditAbsen').classList.add('flex');
}

function simpanEditAbsen() {
  const id = document.getElementById('editAbsId').value;
  const idx = appData.absensi.findIndex(x => x.id === id);
  if (idx > -1) {
    appData.absensi[idx].status = document.getElementById('editAbsStatus').value;
    appData.absensi[idx].keterangan = document.getElementById('editAbsKet').value.trim();
  }
  saveAllToStorage();
  document.getElementById('modalEditAbsen').classList.add('hidden');
  renderAll();
}

function hapusAbsensi(id) {
  if (!confirm('Hapus catatan absensi ini?')) return;
  appData.absensi = appData.absensi.filter(x => x.id !== id);
  saveAllToStorage();
  renderAll();
}

function renderRekap() {
  const filterBln = document.getElementById('filterBulanRekap').value;
  document.getElementById('labelPeriodePdf').innerText = filterBln ? 'Periode Bulan: ' + filterBln : 'Periode: Seluruh Kegiatan Tercatat';

  const filteredAbs = filterBln ? appData.absensi.filter(a => a.tanggal.startsWith(filterBln)) : appData.absensi;
  const tbody = document.getElementById('tbodyRekapPdf');

  tbody.innerHTML = appData.anggota.map((ang, i) => {
    const logs = filteredAbs.filter(x => x.namaAnggota === ang.nama);
    const h = logs.filter(x => x.status === 'Hadir').length;
    const iz = logs.filter(x => x.status === 'Izin').length;
    const s = logs.filter(x => x.status === 'Sakit').length;
    const al = logs.filter(x => x.status === 'Alpha').length;
    const total = h + iz + s + al;
    const persen = total > 0 ? Math.round((h / total) * 100) + '%' : '0%';

    return `
      <tr>
        <td class="border border-slate-800 p-2 text-center">${i + 1}</td>
        <td class="border border-slate-800 p-2 font-semibold">${ang.nama}</td>
        <td class="border border-slate-800 p-2 text-center">${ang.kelas}</td>
        <td class="border border-slate-800 p-2 text-center font-bold">${h}</td>
        <td class="border border-slate-800 p-2 text-center">${iz}</td>
        <td class="border border-slate-800 p-2 text-center">${s}</td>
        <td class="border border-slate-800 p-2 text-center">${al}</td>
        <td class="border border-slate-800 p-2 text-center font-bold">${persen}</td>
      </tr>
    `;
  }).join('');
}

function updateTtdPreview() {
  document.getElementById('previewTtdTanggal').innerText = document.getElementById('ttdTanggalSurat').value;
  const nip = document.getElementById('nipKepsek').value.trim();
  document.getElementById('previewNipKepsek').innerText = nip ? nip : 'NIP. -';
}

function downloadRekapPDF() {
  const element = document.getElementById('pdfArea');
  const opt = {
    margin: 10,
    filename: 'Rekap_Absensi_Rohis_Al_Ammar_SMAN1_Pronojiwo.pdf',
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2 },
    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
  };
  html2pdf().set(opt).from(element).save();
}

// 4. ANGGOTA
function renderAnggota() {
  const tbody = document.getElementById('tbodyAnggota');
  tbody.innerHTML = appData.anggota.map((a, i) => `
    <tr>
      <td class="p-3">${i + 1}</td>
      <td class="p-3 font-bold">${a.nama}</td>
      <td class="p-3">${a.kelas}</td>
      <td class="p-3">${a.jk}</td>
      <td class="p-3">${a.divisi || '-'}</td>
      <td class="p-3 text-center space-x-2">
        <button onclick="editAnggota('${a.id}')" class="text-amber-600 font-bold text-xs hover:underline">Edit</button>
        <button onclick="hapusAnggota('${a.id}')" class="text-red-600 font-bold text-xs hover:underline">Hapus</button>
      </td>
    </tr>
  `).join('');
}

function simpanAnggota(e) {
  e.preventDefault();
  const id = document.getElementById('angId').value;
  const data = {
    id: id || String(Date.now()),
    nama: document.getElementById('angNama').value.trim(),
    kelas: document.getElementById('angKelas').value.trim(),
    jk: document.getElementById('angJk').value,
    divisi: document.getElementById('angDivisi').value.trim()
  };

  if (id) {
    const idx = appData.anggota.findIndex(x => x.id === id);
    if (idx > -1) appData.anggota[idx] = data;
  } else {
    appData.anggota.push(data);
  }
  saveAllToStorage();
  resetFormAnggota();
  renderAll();
}

function editAnggota(id) {
  const a = appData.anggota.find(x => x.id === id);
  if (!a) return;
  document.getElementById('angId').value = a.id;
  document.getElementById('angNama').value = a.nama;
  document.getElementById('angKelas').value = a.kelas;
  document.getElementById('angJk').value = a.jk;
  document.getElementById('angDivisi').value = a.divisi;
}

function hapusAnggota(id) {
  if (!confirm('Hapus anggota ini?')) return;
  appData.anggota = appData.anggota.filter(x => x.id !== id);
  saveAllToStorage();
  renderAll();
}

function resetFormAnggota() {
  document.getElementById('angId').value = '';
  document.getElementById('angNama').value = '';
  document.getElementById('angKelas').value = '';
  document.getElementById('angDivisi').value = '';
}

// 5. PENGATURAN AKUN
function renderAkun() {
  const tbody = document.getElementById('tbodyAkun');
  tbody.innerHTML = appData.akun.map(k => `
    <tr>
      <td class="p-3 font-bold">${k.nama}</td>
      <td class="p-3 font-mono text-xs">${k.username}</td>
      <td class="p-3 font-mono text-xs">${k.password}</td>
      <td class="p-3 text-center space-x-2">
        <button onclick="editAkun('${k.id}')" class="text-amber-600 font-bold text-xs hover:underline">Edit</button>
        <button onclick="hapusAkun('${k.id}')" class="text-red-600 font-bold text-xs hover:underline">Hapus</button>
      </td>
    </tr>
  `).join('');
}

function simpanAkun(e) {
  e.preventDefault();
  const id = document.getElementById('akunId').value;
  const data = {
    id: id || String(Date.now()),
    nama: document.getElementById('akunNama').value.trim(),
    username: document.getElementById('akunUsername').value.trim(),
    password: document.getElementById('akunPassword').value.trim(),
    role: 'Admin Rohis'
  };

  if (id) {
    const idx = appData.akun.findIndex(x => x.id === id);
    if (idx > -1) appData.akun[idx] = data;
  } else {
    appData.akun.push(data);
  }
  saveAllToStorage();
  resetFormAkun();
  renderAkun();
}

function editAkun(id) {
  const k = appData.akun.find(x => x.id === id);
  if (!k) return;
  document.getElementById('akunId').value = k.id;
  document.getElementById('akunNama').value = k.nama;
  document.getElementById('akunUsername').value = k.username;
  document.getElementById('akunPassword').value = k.password;
}

function hapusAkun(id) {
  if (appData.akun.length <= 1) return alert('Minimal harus tersisa 1 akun admin!');
  if (!confirm('Hapus akun admin ini?')) return;
  appData.akun = appData.akun.filter(x => x.id !== id);
  saveAllToStorage();
  renderAkun();
}

function resetFormAkun() {
  document.getElementById('akunId').value = '';
  document.getElementById('akunNama').value = '';
  document.getElementById('akunUsername').value = '';
  document.getElementById('akunPassword').value = '';
}

window.addEventListener('DOMContentLoaded', initApp);
