# APLIKASI ROHIS AL AMMAR - SMAN 1 PRONOJIWO

## Struktur Folder Proyek
- `index.html`      -> Halaman utama aplikasi (Login, Dashboard, Struktur, Kegiatan, Absensi, Anggota, Akun)
- `css/style.css`   -> Pengaturan tema warna hijau zamrud Islami & bingkai logo
- `js/app.js`       -> Seluruh kode logika aplikasi, data awal, penyimpanan, dan export PDF TTD
- `assets/logo-al-ammar.svg` -> Logo resmi Rohis Al-Ammar yang sudah dirapikan

## Cara Menjalankan
1. Ekstrak folder ZIP ini di komputer Anda.
2. Klik dua kali file `index.html` untuk langsung membukanya di browser (Chrome/Edge/Firefox).
3. Login menggunakan akun default:
   - Username: `Dumyati` | Password: `111333`
   - Username: `ikhsan.wijayanto` | Password: `1111333`
4. Untuk mengedit kode lebih lanjut, buka folder ini menggunakan VS Code atau editor teks favorit Anda.
